import PlaygroundSupport
import SpriteKit
import AVFoundation

// categories declaration for collision handling
let steakCategory: UInt32 = 0x1 << 1
let panCategory: UInt32 = 0x1 << 2

public class GameScene: SKScene {
    // variables declaration
    var stove:SKSpriteNode!
    var steak:SKSpriteNode!
    var pan:SKSpriteNode!
    var panCollision:SKSpriteNode!
    
    var label:SKLabelNode!
    var labelNode:SKSpriteNode!
    
    var turnFire:SKSpriteNode!
    var button:SKSpriteNode!
    
    public var act = 0
    // Some aspects of the code can be changed depending on the value of the variable below.
    public var timeToCook = /*#-editable-code*/6/*#-end-editable-code*/
    //#-hidden-code
    var rareSteak:[SKTexture] = []
    var mediumSteak:[SKTexture] = []
    var wellDoneSteak:[SKTexture] = []
    
    var song:AVAudioPlayer!
    var steakGrill:AVAudioPlayer!
    
    var fire:SKEmitterNode!
    
    override public func didMove(to view: SKView) {
        initSprites()
        initBitMask()
        loadAnimation()
        backgroundSound()
    }
    func initSprites(){
        // initialize variable and link to sprites on the GameScene
        steak = childNode(withName: "steak") as? SKSpriteNode
        pan = childNode(withName: "pan") as? SKSpriteNode
        button = childNode(withName: "button")as? SKSpriteNode
        label = childNode(withName: "label")as? SKLabelNode
        labelNode = childNode(withName: "labelNode")as? SKSpriteNode
        stove = childNode(withName: "background")as? SKSpriteNode
        panCollision = childNode(withName: "panCollision")as? SKSpriteNode
        turnFire = childNode(withName: "turnFire")as? SKSpriteNode
        
        //set initial positioning
        stove.position = CGPoint(x: self.position.x, y: self.position.y)
        stove.size = CGSize(width: self.frame.width, height: self.frame.height)
        
        //set initial fill color
        panCollision.color = .clear
        turnFire.color = .clear
        
        //labelNode (text box) size and position
        labelNode.size = CGSize(width: 700, height: 190)
        labelNode.position = CGPoint(x: -100, y: 270)
        
        //label initial text and positioning
        label.text = "Let's see how the Maillard reaction works.\nClick ► to start."
        label.fontColor = .black
        label.position = CGPoint(x: labelNode.position.x, y: labelNode.position.y)
        label.zPosition = 1
        
        //button position
        button.position = CGPoint(x: labelNode.position.x+350, y: labelNode.position.y-70)
    }
    func loadAnimation(){
        //load SKTextures from folder to a array
        for i in 1..<9 {
            let texture = "rare/carne\(i).png"
            rareSteak.append(SKTexture(imageNamed: texture))
        }
        for i in 1..<12 {
            let texture = "medium/carne\(i).png"
            mediumSteak.append(SKTexture(imageNamed: texture))
        }
        for i in 1..<15 {
            let texture = "wellDone/carne\(i).png"
            wellDoneSteak.append(SKTexture(imageNamed: texture))
        }
    }
    func backgroundSound(){
        //background music https://soundimage.org/chiptunes/
        //song: PIXEL ISLAND  http://soundimage.org/wp-content/uploads/2017/03/Pixel-Island.mp3
        if let url = Bundle.main.url(forResource: "PixelIsland", withExtension: "m4a"){
            do {
                song = try AVAudioPlayer(contentsOf: url)
            } catch let error {
                print(error)
            }
            song.prepareToPlay()
            song.volume = 0.5
            song.play()
            song.numberOfLoops = -1
        }
    }
    func grillSound(loops:Int){
        //steak sound effect sound effect: https://freesound.org/people/ToniTobe/sounds/233294/
        if let url = Bundle.main.url(forResource: "steakGrill", withExtension: "m4a"){
            do {
                steakGrill = try AVAudioPlayer(contentsOf: url)
            } catch let error {
                print(error)
            }
            steakGrill.prepareToPlay()
            steakGrill.volume = 2
            steakGrill.play()
            steakGrill.numberOfLoops = loops
        }
    }
    func initBitMask(){
        // collision delegate
        self.physicsWorld.contactDelegate = self as? SKPhysicsContactDelegate
        
        //link nodes to respectively category collision
        steak.physicsBody?.categoryBitMask = steakCategory
        panCollision.physicsBody?.categoryBitMask = panCategory
        
        //what nodes will colide with
        steak.physicsBody?.collisionBitMask = panCategory
        panCollision.physicsBody?.collisionBitMask = steakCategory
        
        //contact detection
        steak.physicsBody?.contactTestBitMask = panCategory
        panCollision.physicsBody?.contactTestBitMask = steakCategory
        
        panCollision.physicsBody?.usesPreciseCollisionDetection = true
    }
    func callEvent(event:Int){
        // function callEvent() changes the events on the scene based on a counter
        switch event {
        case 0:
            label.text = "First drag the steak and drop it in the pan."
            act+=1
        case 1:
            label.text = "Now turn the stove on, to cook the steak,\nby clicking the stove's control wheel."
        case 2:
            label.text = "Pay attention to what happens to the steak."
            act+=1
        case 3:
            if(timeToCook <= 5){
                label.text = "See how the steak is light brown colored? ►"
                
            }else if(timeToCook > 5 && timeToCook < 10){
                label.text = "Wow, this steak got some nice grill marks.\nI bet it tastes good too. ►"
                
            }else if(timeToCook >= 10){
                label.text = "This looks darker than\nthe other cooking times. ►"
                
            }
            act+=1
        case 4:
            if(timeToCook <= 5){
                label.text = "The color indicates the steak is rare\ncooked, some people like their steak\nrare, so nothing is wrong here. ►"
                
            }else if(timeToCook > 5 && timeToCook < 10){
                label.text = "The color indicates the steak is medium\ncooked, most people like their\nsteak like this. ►"
                
            }else if(timeToCook >= 10){
                label.text = "This steak is cooked well done. Lots of chefs\nhate when orders ask for well done steaks,\nbut its a costumer's choice. ►"
                
            }
            act+=1
        case 5:
            label.text = "The amount of time a steak stays in contact with\nthe fire, influences the color, texture and taste,\nbecause more proteins ans carbohydrates \nare burnt over time. "
            act+=1
        case 6:
            if(timeToCook <= 5){
                label.text = "Let's try increase the cooking time,\nto see if something different happens."
                PlaygroundPage.current.assessmentStatus = .fail(hints: ["Change the variable 'cookingTime' and run again"], solution: nil)
    
            }
            else if(timeToCook > 5 && timeToCook < 10){
                label.text = "Try to increase or decrease the \ncooking time to get different results."
                PlaygroundPage.current.assessmentStatus = .fail(hints: ["Change the variable 'cookingTime' and run again"], solution: nil)
                
            }else if(timeToCook >= 10){
                label.text = "Congratulations!, now you can prepare\nyour steak knowing exactly\nwhats happening and preparing it\nthe way you like it."
                PlaygroundPage.current.assessmentStatus = .pass(message: "Nice! Let's check the next reaction [Next Page](@next)")
            }
        default:
            print("switch default")
        }
    }
    
    func grillingSteak(){
        // run animations according to cooking time
        let timeInterval = 1.0
        var cooking:SKAction!
        var numLoops:Int!
        
        if(timeToCook <= 5){
            numLoops = 3
            cooking = SKAction.animate(with: rareSteak, timePerFrame: timeInterval)
        }
        else if(timeToCook > 5 && timeToCook < 10){
            numLoops = 4
            cooking = SKAction.animate(with: mediumSteak, timePerFrame: timeInterval)
        }
        else if(timeToCook >= 10){
            numLoops = 5
            cooking = SKAction.animate(with: wellDoneSteak, timePerFrame: timeInterval)
        }
        steak.run(cooking, completion: {
            self.callEvent(event: self.act)
            self.fire.removeAllActions()
            self.fire.removeFromParent()
            self.rareSteak.removeAll()
            self.mediumSteak.removeAll()
            self.wellDoneSteak.removeAll()
        })
        grillSound(loops: numLoops)
    }
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        //reconigzes screen touch and specific elements being touched
        let touch = touches.first
        let location = touch?.location(in: self)
        if((button.frame.contains(location!) && act == 0) || (button.frame.contains(location!) && act == 4)||(button.frame.contains(location!) && act == 5) || (button.frame.contains(location!) && act == 6)){
            callEvent(event: act)
            
        }
        if(turnFire.frame.contains(location!) && act == 2){
            fire = SKEmitterNode(fileNamed: "fire.sks")
            fire.position.x = pan.position.x-35
            fire.position.y = pan.position.y-100
            addChild(fire)
            grillingSteak()
            callEvent(event: act)
        }
    }
    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        //allow elements to be dragged
        let touch = touches.first
        let location  = touch?.location(in: self)
        if(steak.frame.contains(location!) && act == 1){
            steak.position = location!
        }
    }
}

extension GameScene: SKPhysicsContactDelegate{
    //extension that handles the contactBitMask and collision events
    public func didBegin(_ contact: SKPhysicsContact) {
        let bodyA = contact.bodyA.categoryBitMask
        let bodyB = contact.bodyB.categoryBitMask
        if(bodyA == steakCategory || bodyB == steakCategory){
            if(bodyA == steakCategory){
                panCollision.physicsBody = nil
                let move = SKAction.move(to: CGPoint(x: panCollision.position.x, y: panCollision.position.y+65), duration: 1.0)
                callEvent(event: act)
                act+=1
                steak.run(move)
            }
            if(bodyB == steakCategory){
                panCollision.physicsBody = nil
                let move = SKAction.move(to: CGPoint(x: panCollision.position.x, y: panCollision.position.y+65), duration: 1.0)
                callEvent(event: act)
                act+=1
                steak.run(move)
            }
        }
    }
}

