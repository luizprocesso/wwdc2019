
/*:
 
 # Maillard Reaction:
 
 This reaction takes place when proteins or aminoacids and carbohydrates are in direct contact with a heat source like ovens, grills or a pan.
 
 Meats(🥩,🍖), breads(🍞, 🥐, 🥧), cheeses(🧀,) and also vegetables(🍆, 🥔, 🥕) are the most common foods where this reaction happens. You may think meats don't have carbohydrates and breads/vegetables don't have protein, but they actually have both(in different amonts) in their composition.
 
The heat caramelizes the carbohydrates and proteins giving the preparation a golden brown color, characteristic flavor and scent. If you boil, in some water, a beef, a bread, or a zuccini, it won't get the same color, texture and taste, because there is no direct contact to the heat source.
 
Also the amout of time you expouse a dish to a heat source changes it's color and taste. If it stays to much in a grill, it could burn and the golden brown color starts getting darker and the taste more bitter.
 
 Let's run the code and see how this reaction happens while cooking.
 
 */

//#-hidden-code
import PlaygroundSupport
import SpriteKit
import AVFoundation


//#-end-hidden-code
//better viewed full screen, landscape mode.

//available cooking times: one to ten.
var cookingTime = /*#-editable-code*/6/*#-end-editable-code*/

//#-hidden-code
let sceneView = SKView(frame: CGRect(x:0 , y:0, width: 640, height: 480))
if let scene = GameScene(fileNamed: "GameScenePage1"){
    scene.scaleMode = .aspectFit
    scene.timeToCook = cookingTime
    
    sceneView.presentScene(scene)
}
PlaygroundSupport.PlaygroundPage.current.liveView = sceneView

//#-end-hidden-code
/*:
 [Previous Page](@previous) - [Next Page](@next)
 */
