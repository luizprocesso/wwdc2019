/*:
 # Whipped Egg Whites:
 
 A egg white can be whipped, changing it's form and making it a new ingredient with different aspects and usages.
 
 Firts let's understand more about the egg 🍳. It's composed by the egg white and yolk. Usually one of each is present in a egg but eggs without yolk exist and eggs with two or more yolks also exist. Both case are rare but the first one means that a natural abortion happend and the second twins were growing in that egg .
 
 * **Egg whites:** are basically water and protein. the protein is of the globular type, which doesn't have structure while it's raw(a beef has a fibrous protein for comparisson), making ideal for mixing with cakes and puddings, for example, because it homogeneously blends with the mixture and after cooking the form and shape of the recipient is mantained after you take the cake off the cake pan.
 
 * **Yolks:** in the other hand are compoused by protein and lipid. Also can give structure to mixture after being blended in and cooked, but the presence of lipid instead of water makes the mixture much more heavier and if whipped, doesn't get the same volume and shape of a egg white.
 
 Let's run the code and make some whipped egg whites.
 */

//#-hidden-code
import PlaygroundSupport
import SpriteKit
import AVFoundation

//#-end-hidden-code
//better viewed in full screen, portrait mode.

//speeds available:1,2 or 3
var whippingSpeed = /*#-editable-code*/2/*#-end-editable-code*/
//#-hidden-code

let sceneView = SKView(frame: CGRect(x:0 , y:0, width: 640, height: 480))
if let scene = GameScene(fileNamed: "GameScenePage2.sks") {
    scene.scaleMode = .aspectFit
    scene.speedWhipping = whippingSpeed
    sceneView.presentScene(scene)
}

PlaygroundSupport.PlaygroundPage.current.liveView = sceneView
//#-end-hidden-code
/*:
 [Previous Page](@previous)
 */
