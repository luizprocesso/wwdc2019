
import PlaygroundSupport
import SpriteKit
import AVFoundation

// categories declaration for collision handling
let eggCategory: UInt32 = 0x1 << 1
let bowlCategory: UInt32 = 0x1 << 2
let fuetCategory: UInt32 = 0x1 << 3
let yolkCategory: UInt32 = 0x1 << 4

public class GameScene: SKScene {
    
    // variables declaration
    var label:SKLabelNode!
    var labelNode:SKSpriteNode!
    
    var egg:SKSpriteNode!
    var eggYolk: SKSpriteNode!
    var bowl:SKSpriteNode!
    var bowlColision:SKSpriteNode!
    var fuet:SKSpriteNode!
    var button:SKSpriteNode!
    
    public var speedWhipping = 1
    var act = 1
    
    var song:AVAudioPlayer!
    var crackingEgg:AVAudioPlayer!
    var whippingEggs:AVAudioPlayer!
    
    var eggWhiteAnimation:[SKTexture] = []
    
    override public func didMove(to view: SKView) {
        initSprites()
        initBitMask()
        loadAnimation()
        backgroundSound()        
    }
    func initSprites(){
        // link the node to a element on the gameScene
        bowl = childNode(withName: "bowl")as? SKSpriteNode
        bowlColision = childNode(withName: "bowlColision") as? SKSpriteNode
        fuet = childNode(withName: "fuet") as? SKSpriteNode
        label = childNode(withName: "label") as? SKLabelNode
        labelNode = childNode(withName: "labelNode")as? SKSpriteNode
        button = childNode(withName: "button")as? SKSpriteNode
        egg = childNode(withName: "egg1")as? SKSpriteNode
        eggYolk = childNode(withName: "eggYolk") as? SKSpriteNode
        
        //initialize nodes colors, labels text and initial positioning
        bowlColision.color = .clear
        labelNode.size = CGSize(width: 600, height: 300)
        labelNode.position = CGPoint(x: self.position.x, y: self.position.y+300)
        label.fontColor = .black
        label.zPosition = 1
        label.text = "I believe after you read the introduction\nyou are curious about how these cool\nreactions happens. Without futher do,\nclick ► to prepare your whipped\neggs."
        label.position = CGPoint(x: labelNode.position.x, y: labelNode.position.y+5)
        button.position = CGPoint(x: labelNode.position.x + 300, y: labelNode.position.y - 140)
    }
    func initBitMask(){
        
        // create physicsBody to allow collisions
        self.physicsWorld.contactDelegate = self as? SKPhysicsContactDelegate
        bowlColision.physicsBody?.categoryBitMask = bowlCategory
        fuet.physicsBody?.categoryBitMask = fuetCategory
        egg.physicsBody?.categoryBitMask = eggCategory
        
        //category bitmask for collision detection
        bowlColision.physicsBody?.collisionBitMask = fuetCategory | eggCategory
        bowlColision.physicsBody?.contactTestBitMask = fuetCategory | eggCategory
        fuet.physicsBody?.contactTestBitMask =  bowlCategory
        egg.physicsBody?.contactTestBitMask = bowlCategory
        bowlColision.physicsBody?.usesPreciseCollisionDetection = true
    }
   func loadAnimation(){
        self.eggWhiteAnimation.removeAll()
        //load textures from folder and append into an array
        for i in 1...72{
            let texture = "sprites/clara\(i).png"
            eggWhiteAnimation.append(SKTexture(imageNamed: texture))
        }
    }
    func backgroundSound(){
        //playing background sound: https://soundimage.org/chiptunes/
          //song: INKY AND BLINKY’S BAND http://soundimage.org/wp-content/uploads/2017/03/Inky-and-Blinkys-Band.mp3
        if let url = Bundle.main.url(forResource: "InkyAndBlinkysBand", withExtension: "m4a"){
            do {
                song = try AVAudioPlayer(contentsOf: url)
            } catch let error {
                print(error)
            }
            song.prepareToPlay()
            song.volume = 0.5
            song.play()
            song.numberOfLoops = -1
        }
    }
    func crackEggs(){
        //cracking egg sound effect: https://freesound.org/people/FngerSounds/sounds/250133/
      
        if let url = Bundle.main.url(forResource: "eggCracking", withExtension: "m4a"){
            do {
                crackingEgg = try AVAudioPlayer(contentsOf: url)
            } catch let error {
                print(error)
            }
            crackingEgg.prepareToPlay()
            crackingEgg.volume = 2
            crackingEgg.play()
        }
    }
    func whippeningEgg(loops:Int){
        //fuet scratching bowl while whipping egg whites effect
        //this sound effect I did my self. recorded me whippenig a empty bowl.
        if let url = Bundle.main.url(forResource: "whippeningEgg", withExtension: "m4a"){
            do {
                whippingEggs = try AVAudioPlayer(contentsOf: url)
            } catch let error {
                print(error)
            }
            whippingEggs.prepareToPlay()
            whippingEggs.volume = 2
            whippingEggs.play()
            whippingEggs.numberOfLoops = loops
        }
    }
    func fuetMoviment(speed:Int, fuet:SKSpriteNode){
        
        //run animations - fuet spinning and egg whites being whipped
        
        let rotationMovePlus:CGFloat = 20
        let rotationMoveMinus:CGFloat = -20
        var actions:[SKAction] = []
        var timeFuet:TimeInterval!
        var timeBowl:TimeInterval!
        var repeats = 0
        
        if(speed <= 1){
            timeFuet = 0.25
            timeBowl = 0.18
            repeats = 4}
        else if(speed == 2){
            timeFuet = 0.075
            timeBowl = 0.075
            repeats = 6}
        else if(speed >= 3){
            timeFuet = 0.0375
            timeBowl = 0.06
            repeats = 9}
        
        let move1 = SKAction.move(by: CGVector(dx: rotationMoveMinus, dy: rotationMovePlus), duration: timeFuet)
        let move2 = SKAction.move(by: CGVector(dx: rotationMoveMinus, dy: rotationMovePlus), duration: timeFuet)
        let move3 = SKAction.move(by: CGVector(dx: rotationMoveMinus, dy: rotationMovePlus), duration: timeFuet)
        
        let move4 = SKAction.move(by: CGVector(dx: rotationMoveMinus, dy: rotationMoveMinus), duration: timeFuet)
        let move5 = SKAction.move(by: CGVector(dx: rotationMoveMinus, dy: rotationMoveMinus), duration: timeFuet)
        let move6 = SKAction.move(by: CGVector(dx: rotationMoveMinus, dy: rotationMoveMinus), duration: timeFuet)
        
        let move7 = SKAction.move(by: CGVector(dx: rotationMovePlus, dy: rotationMoveMinus), duration: timeFuet)
        let move8 = SKAction.move(by: CGVector(dx: rotationMovePlus, dy: rotationMoveMinus), duration: timeFuet)
        let move9 = SKAction.move(by: CGVector(dx: rotationMovePlus, dy: rotationMoveMinus), duration: timeFuet)
        
        let move10 = SKAction.move(by: CGVector(dx: rotationMovePlus, dy: rotationMovePlus), duration: timeFuet)
        let move11 = SKAction.move(by: CGVector(dx: rotationMovePlus, dy: rotationMovePlus), duration: timeFuet)
        let move12 = SKAction.move(by: CGVector(dx: rotationMovePlus, dy: rotationMovePlus), duration: timeFuet)
        
        let animation = SKAction.animate(with: eggWhiteAnimation, timePerFrame: timeBowl)
        
        actions.append(move1)
        actions.append(move2)
        actions.append(move3)
        actions.append(move4)
        actions.append(move5)
        actions.append(move6)
        actions.append(move7)
        actions.append(move8)
        actions.append(move9)
        actions.append(move10)
        actions.append(move11)
        actions.append(move12)
        
        fuet.run(SKAction.repeat(SKAction.sequence(actions), count: repeats))
        bowl.run(animation, completion: {
            self.act+=1
            self.callEvent(event: self.act)
        })
    }
    func callEvent(event:Int){
        // function callEvent() changes the events on the scene based on a counter
        switch event{
        case 1:
            label.text = "First we have to put our egg in the\nbowl.Take the egg, on the left side\nand place it inside the bowl."
            act+=1
        case 2:
            label.text = "For whipped egg whites we don't use\nyolks, so click the yolk to separete\nboth ingredients a part."
        case 3:
            label.text = "On your right you will see a utensil, it's\ncalled 'fuet', move it inside the bowl."
        case 4:
            label.text = "Well done! Click in the bowl\nto whip your egg whites."
        case 5:
            if(speedWhipping == 2){
                label.text = "Wow! look at that! What just\nhappened? How the egg whites \nhave changed just by whippening it? \nClick ► to understand why."
                act+=2}else{
                label.text = "Wow! look at that! What just\nhappened? How the egg whites \nhave changed just by whippening it? \nClick ► to understand why."
                act+=1}
        case 6:
            if(speedWhipping <= 1 ){
                label.text = "I guess you're asking: 'wasn't that \na little slow?'The answer is yes, \nbut we will see what happened\nahead and the result is correct\nthe way it is. ►"
                act+=1}else if(speedWhipping >= 3){
                label.text = "Did you notice how faster it\nfinished. Clearly the whippening\nspeed makes huge diffrence\nin the process. ►"
                act+=1
                
            }
        case 7:
            label.text = "As explained egg whites are formed by\nprotein and water. While whippening,\nthe protein cells break absorbing what\nis around it, air and water, giving volume\nand losing transparency. ►"
            act+=1
        case 8:
            label.text = "In a kitchen this technique is used\nin baking products, suffles and else\nwhere imagination takes you. To make\nthis process faster you can increase\nthe whippening speed by making\nquicker moves or using devices\nsuch as cake mixers. ►"
            act+=1
        case 9:
            if(speedWhipping >= 3){
                label.text = "Now that you know how this\nprocess work, try making a cake.\nDon't forget to save a slice \nfor myself. "
                 PlaygroundPage.current.assessmentStatus = .pass(message: " Nicely done, you have just completed the basics of food science, Thanks for Playing")
            }else{
                label.text = "Change the editable variable to see how\ndifferent whippening speeds affect the\nprocess of making whipped egg whites."
                PlaygroundPage.current.assessmentStatus = .fail(hints: ["Change the variable 'whippingSpeed' and run again"], solution: nil)
            }
        default:
            act+=1
        }
    }
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        //reconigzes screen touch and specific elements being touched
        let touch = touches.first
        let location = touch?.location(in: self)
        
        if(button.frame.contains(location!) && act != 2){
            callEvent(event: act)
        }
        if(eggYolk.frame.contains(location!) && act == 2){
            eggYolk.removeFromParent()
            act+=1
            callEvent(event: act)
        }
        if(bowlColision.frame.contains(location!) && act == 4){
            fuetMoviment(speed: speedWhipping, fuet:fuet)
            if(speedWhipping <= 1){
                whippeningEgg(loops:2)
            }else if (speedWhipping == 2){
                whippeningEgg(loops:0)
            }else if(speedWhipping >= 3){
                whippeningEgg(loops:0)
            }
        }
    }
    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        //allow elements to be dragged
        let touch = touches.first
        let location = touch?.location(in: self)
        if(fuet.frame.contains(location!) && act<4){
            fuet.position = location!
        }else if(egg.frame.contains(location!)){
            egg.position = location!
        }
    }
}
extension GameScene: SKPhysicsContactDelegate{
    
    //extension that handles the contactBitMask and collision events
    public func didBegin(_ contact: SKPhysicsContact) {
        
        let bodyA = contact.bodyA.categoryBitMask
        let bodyB = contact.bodyB.categoryBitMask
        
        if ((bodyA == eggCategory || bodyB == eggCategory) && (bodyA == bowlCategory || bodyB == bowlCategory)){
            if(act == 2){
                if(bodyA == eggCategory){
                    crackEggs()
                    contact.bodyA.node?.removeFromParent()
                    eggYolk.position = CGPoint(x: bowlColision.position.x, y: bowlColision.position.y+30)
                    bowl.texture = SKTexture(imageNamed: "eggWhite")
                    //act+=1
                    callEvent(event: act)
                }
                else if(bodyB == eggCategory){
                    crackEggs()
                    contact.bodyB.node?.removeFromParent()
                    eggYolk.position = CGPoint(x: bowlColision.position.x, y: bowlColision.position.y+30)
                    bowl.texture = SKTexture(imageNamed: "eggWhite")
                    //act+=1
                    callEvent(event: act)
                }
            }
        }
        if ((bodyA == fuetCategory || bodyB == fuetCategory) && (bodyA == bowlCategory || bodyB == bowlCategory)){
            if(bodyA == fuetCategory && act == 3){
                let move = SKAction.move(to: CGPoint(x: bowlColision.position.x+140, y: bowlColision.position.y+35), duration: 1.0)
                let rotate = SKAction.rotate(byAngle: 1.5, duration: 1.0)
                fuet.run(SKAction.sequence([move,rotate]))
                bowlColision.physicsBody = nil
                act+=1
                callEvent(event: act)
            }
            if(bodyB == fuetCategory && act == 3){
                let move = SKAction.move(to: CGPoint(x: bowlColision.position.x+140, y: bowlColision.position.y+35), duration: 1.0)
                let rotate = SKAction.rotate(byAngle: 1.5, duration: 1.0)
                fuet.run(SKAction.sequence([move,rotate]))
                bowlColision.physicsBody = nil
                act+=1
                callEvent(event: act)
            }
        }
    }
}


