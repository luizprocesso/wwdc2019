/*:
 # Food Science
 
 * ## Hello there, welcome.

 I don't know if you ever notice, but there are lots of reactions happening in a kitchen, in a daily basis. Doesn't matter if it's at home or in a professional enviroment, while cooking things happen and most of us don't have a clue why. Knowing exactly what is happening helps to get preparations right from start, makes easy to reproduce by others and even if different people are doing differents steps of the same recipe the result will be consistent.
 
 

 * ## Real Science
 
 Food Science is a multidisciplinary field of study that focus os experimenting all physical-chemical, microbiological, biochemicals and technological aspects of foods. This knowledge is used by all the supply chain, from raw to plate. That means a farmer needs to know whats happening to what they grow and a chef needs to know what will happen with what they cook.
 
 The first time mankind had the need to understand their food was when the need to preserve food started. We could have crops, herds, but after the harvest, it had to be consumed right away. The first preserving process was cooking, compared to a raw beef a cooked one lasts longer. Followed by drying products, first wind based drying then salting, use of oil and vinagar, cooling/freezing and the modern ways of conserving food, discovered after extensive studies of different food's aspects. Today we still use all the preserving methods, mostly because of the particular taste those techniques give.
 
 The field gained more attention after the second half of the 19th century, where governaments started having a bigger concern about the food suply since the society and cities were growing. Knowing how to delay a food rotten process would mean a better fed population.
 
Renowed Univesities have departaments for this field, mostly of then: agriculture, chemical, food engineering and nutrition, but also culinary institutes such as CIA (not that CIA 🤣🤣) the Culinary Intitute of America and Alicia Foundation, have programs exclusively for the subject, because of the food service scenario, chefs and restaurants are creating new dishes and ways of preparation. Escoffier and Carême, in the beginning of the 20th century, started documenting cooking processes and phenomenons, so future chef wouldn't start from zero. Before them many things we think it's standard today, would never exist. Nowadays Ferran Adria a famous Catalan chef is the main character of food science being used in the restaurant enviroment, with his Molecular Gastronomy studies.

 */

/*:
 ## About This Playground
 
 Here two reactions are explained. They are used every day in a kitchen enviroment, profesional or not. Hope you enjoy it and without futher do [let's begin.](@next).
*/
